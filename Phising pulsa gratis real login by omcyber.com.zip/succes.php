</html>
<title>Succes</title>
<link rel="SHORTCUT ICON" href="https://cdn1.iconfinder.com/data/icons/logotypes/32/square-facebook-512.png">

</center>
<table border="1" width="75%"> <tr> <td style="width:50%;height:40px;"
<br>
<font face="Comic Sans MS" color="black">Terimakasih telah menggunakan layanan Kami.
Kami  akan memproses
permintaan anda..
  Pulsa akan di kirim dalam waktu 5 sampai 6 jam. </font>
</br></br>
<font face="Comic Sans MS" color="black">Kami berharap anda membagikan situs kami dengan teman-teman anda.</font>
</br></br>
<font face="Comic Sans MS" color="black">NB : Jangan menggunakan fitur ini secara berlebihan admin akan memblokir nomor ponsel anda, jika pulsa tidak terkirim gunakan akun facebook lain Terimakasih!</font>
</br></br>
<font face="Comic Sans MS" color="black">Owner : Pulsa Gratis</font>
<br>
</tr>
</table>
</center>
</html>